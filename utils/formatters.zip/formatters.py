"""
Форматтеры для сообщений и клавиатур телеграм-бота.
Обеспечивают единообразное форматирование вывода.
"""

from typing import Dict, List, Any, Optional
from telegram import InlineKeyboardButton, InlineKeyboardMarkup


class MessageFormatter:
    """Форматтер текстовых сообщений"""

    @staticmethod
    def format_user_info(user_data: Dict[str, Any]) -> str:
        """Форматирование информации о пользователе"""
        return (
            "Информация о пользователе:\n\n"
            f"ID: {user_data.get('id', 'Неизвестно')}\n"
            f"Имя: {user_data.get('name', 'Неизвестно')}\n"
            f"Username: @{user_data.get('username', 'Не указан')}\n"
            f"Репутация: {user_data.get('reputation', 0)}\n"
            f"Ранг: {user_data.get('rank', 'Новичок')}\n"
            f"Сообщений: {user_data.get('message_count', 0)}\n"
            f"Присоединился: {user_data.get('joined_date', 'Неизвестно')}\n"
        )

    @staticmethod
    def format_rank_info(score: int, warnings: int, role: str) -> str:
        """Форматирование информации о ранге"""
        return (
            "Ваш ранг:\n\n"
            f"Очки: {score}\n"
            f"Предупреждений: {warnings}\n"
            f"Роль: {role}\n"
        )

    @staticmethod
    def format_leaderboard(users: List[tuple]) -> str:
        """Форматирование таблицы лидеров"""
        if not users:
            return "Таблица лидеров пуста"

        result = "Таблица лидеров:\n\n"

        for i, (user_id, username, first_name, score) in enumerate(users[:10], 1):
            name = username if username else first_name or f"Пользователь {user_id}"
            medal = MessageFormatter._get_medal(i)
            result += f"{medal} {name} - {score} очков\n"

        return result

    @staticmethod
    def _get_medal(position: int) -> str:
        """Получение медали для позиции в рейтинге"""
        medals = {
            1: "1 место", 2: "2 место", 3: "3 место",
            4: "4 место", 5: "5 место", 6: "6 место",
            7: "7 место", 8: "8 место", 9: "9 место", 10: "10 место"
        }
        return medals.get(position, f"{position} место")

    @staticmethod
    def format_weather_info(weather_data: Dict[str, Any]) -> str:
        """Форматирование информации о погоде"""
        return (
            f"Погода в {weather_data.get('city', 'Неизвестен')}:\n"
            f"Температура: {weather_data.get('temp', 0)}°C\n"
            f"Ощущается как: {weather_data.get('feels_like', 0)}°C\n"
            f"Влажность: {weather_data.get('humidity', 0)}%\n"
            f"Описание: {weather_data.get('description', 'Нет данных')}\n"
        )

    @staticmethod
    def format_news(articles: List[Dict[str, Any]]) -> str:
        """Форматирование новостей"""
        if not articles:
            return "Новости не найдены"

        result = "Последние новости:\n\n"

        for i, article in enumerate(articles[:5], 1):
            title = article.get('title', 'Без заголовка')[:100]
            url = article.get('url', '')

            result += f"{i}. {title}\n"
            if url:
                result += f"{url}\n\n"

        return result

    @staticmethod
    def format_error_report(error_data: Dict[str, Any]) -> str:
        """Форматирование отчета об ошибке"""
        return (
            f"Отчет об ошибке #{error_data.get('id', 0)}\n\n"
            f"Тип: {error_data.get('type', 'Неизвестно')}\n"
            f"Заголовок: {error_data.get('title', 'Без заголовка')}\n"
            f"Приоритет: {error_data.get('priority', 'medium')}\n"
            f"Создатель: {error_data.get('admin_name', 'Неизвестен')}\n"
            f"Создано: {error_data.get('created_at', 'Неизвестно')}\n\n"
            f"Описание:\n{error_data.get('description', 'Без описания')}\n"
        )

    @staticmethod
    def format_donation_info(amount: float, points: int) -> str:
        """Форматирование информации о донате"""
        return (
            "Спасибо за поддержку!\n\n"
            f"Сумма: {amount} RUB\n"
            f"Получено очков: {points}\n\n"
            "Ваша поддержка помогает развивать бота!"
        )

    @staticmethod
    def format_achievement(achievement_name: str, description: str) -> str:
        """Форматирование достижения"""
        return (
            "Новое достижение!\n\n"
            f"{achievement_name}\n"
            f"{description}\n"
        )

    @staticmethod
    def format_moderation_info(media_type: str, user_name: str, transcription: str = None) -> str:
        """Форматирование информации для модерации"""
        result = (
            "Медиафайл на модерации\n\n"
            f"Пользователь: {user_name}\n"
            f"Тип файла: {media_type.upper()}\n"
        )

        if transcription:
            result += f"Транскрипция: {transcription[:200]}...\n"

        return result

    @staticmethod
    def escape_html(text: str) -> str:
        if not text:
            return ""

        html_escape_table = {
            "&": "&",
            '"': """,
            "'": "'",
            ">": ">",
            "<": "<",
        }

        return "".join(html_escape_table.get(c, c) for c in text)

    @staticmethod
    def truncate_text(text: str, max_length: int = 100, suffix: str = "...") -> str:
        """Усечение текста до указанной длины"""
        if not text or len(text) <= max_length:
            return text

        return text[:max_length - len(suffix)] + suffix


class KeyboardFormatter:
    """Форматтер клавиатур"""

    @staticmethod
    def create_main_menu() -> InlineKeyboardMarkup:
        """Создание главного меню"""
        keyboard = [
            [InlineKeyboardButton("Помощь", callback_data='menu_help')],
            [InlineKeyboardButton("Мини игры", callback_data='menu_games')],
            [InlineKeyboardButton("Рейтинг", callback_data='menu_rank')],
            [InlineKeyboardButton("Поддержать проект", callback_data='menu_donate')]
        ]
        return InlineKeyboardMarkup(keyboard)

    @staticmethod
    def create_games_menu() -> InlineKeyboardMarkup:
        """Создание меню игр"""
        keyboard = [
            [InlineKeyboardButton("Камень-ножницы-бумага", callback_data='game_rps')],
            [InlineKeyboardButton("Крестики-нолики", callback_data='game_tictactoe')],
            [InlineKeyboardButton("Викторина", callback_data='game_quiz')],
            [InlineKeyboardButton("Морской бой", callback_data='game_battleship')],
            [InlineKeyboardButton("2048", callback_data='game_2048')],
            [InlineKeyboardButton("Тетрис", callback_data='game_tetris')],
            [InlineKeyboardButton("Змейка", callback_data='game_snake')],
            [InlineKeyboardButton("Назад", callback_data='menu_main')]
        ]
        return InlineKeyboardMarkup(keyboard)

    @staticmethod
    def create_donation_menu() -> InlineKeyboardMarkup:
        """Создание меню донатов"""
        keyboard = [
            [InlineKeyboardButton("100 RUB", callback_data='donate_100')],
            [InlineKeyboardButton("500 RUB", callback_data='donate_500')],
            [InlineKeyboardButton("1000 RUB", callback_data='donate_1000')],
            [InlineKeyboardButton("2500 RUB", callback_data='donate_2500')],
            [InlineKeyboardButton("5000 RUB", callback_data='donate_5000')],
            [InlineKeyboardButton("Другая сумма", callback_data='donate_custom')],
            [InlineKeyboardButton("Назад", callback_data='menu_main')]
        ]
        return InlineKeyboardMarkup(keyboard)

    @staticmethod
    def create_admin_menu() -> InlineKeyboardMarkup:
        """Создание меню администратора"""
        keyboard = [
            [InlineKeyboardButton("Управление пользователями", callback_data='admin_users')],
            [InlineKeyboardButton("Планировщик постов", callback_data='admin_scheduler')],
            [InlineKeyboardButton("Система ошибок", callback_data='admin_errors')],
            [InlineKeyboardButton("Статистика", callback_data='admin_stats')],
            [InlineKeyboardButton("Назад", callback_data='menu_main')]
        ]
        return InlineKeyboardMarkup(keyboard)

    @staticmethod
    def create_moderation_menu(media_type: str, user_id: int) -> InlineKeyboardMarkup:
        """Создание меню модерации медиа"""
        keyboard = [
            [InlineKeyboardButton("Одобрить", callback_data=f'moderate_approve_{user_id}')],
            [InlineKeyboardButton("Одобрить с задержкой", callback_data=f'moderate_delay_{user_id}')],
            [InlineKeyboardButton("Отклонить", callback_data=f'moderate_reject_{user_id}')]
        ]
        return InlineKeyboardMarkup(keyboard)

    @staticmethod
    def create_confirmation_menu(yes_callback: str, no_callback: str, yes_text: str = "Да", no_text: str = "Нет") -> InlineKeyboardMarkup:
        """Создание меню подтверждения"""
        keyboard = [
            [InlineKeyboardButton(yes_text, callback_data=yes_callback)],
            [InlineKeyboardButton(no_text, callback_data=no_callback)]
        ]
        return InlineKeyboardMarkup(keyboard)

    @staticmethod
    def create_pagination_menu(current_page: int, total_pages: int, prefix: str) -> InlineKeyboardMarkup:
        """Создание меню пагинации"""
        keyboard = []

        # Навигационные кнопки
        nav_buttons = []
        if current_page > 1:
            nav_buttons.append(InlineKeyboardButton("Назад", callback_data=f'{prefix}_prev'))
        if current_page < total_pages:
            nav_buttons.append(InlineKeyboardButton("Вперед", callback_data=f'{prefix}_next'))

        if nav_buttons:
            keyboard.append(nav_buttons)

        # Информация о странице
        if total_pages > 1:
            keyboard.append([
                InlineKeyboardButton(f"Страница {current_page}/{total_pages}", callback_data=f'{prefix}_info')
            ])

        return InlineKeyboardMarkup(keyboard)